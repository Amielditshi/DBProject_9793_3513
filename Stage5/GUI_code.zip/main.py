from dashboard import launch_dashboard

if __name__ == "__main__":
    launch_dashboard()
